#include "keypad.h"
#include "lcd.h"
#include "timer.h"
#include "uart.h"
#include "avr/io.h"
#include <util/delay.h>
#include <avr/interrupt.h>

#define DELAY      	10

#define START_CAR	1
#define DISPLAY		2
#define FAULTS		3
#define STOP_CAR	4
#define EXIT		5
#define CONT		5

#define P001_CODE	1
#define P002_CODE	2

#define CLOSE		0
#define OPEN		1

#define FALSE_START		200

void home_display(void);

uint8 g_car_state=0;

int main(){

	SREG|=(1<<7);
	LCD_init();

	UART_ConfigType uart_config;
	uart_config.baud_rate =9600;
	uart_config.bit_data=EIGHT_BIT;
	uart_config.parity=UART_PARITY_OFF;
	uart_config.stop_bit=TWO_BIT;
	UART_init(&uart_config);

	Timer_ConfigType timer_config;
	timer_config.timer_ID= TIMER1_ID;
	timer_config.timer_InitialValue= 0;
	timer_config.timer_clock=TMR_PRESCALER_1024 ;
	timer_config.timer_compare_MatchValue=7812;
	timer_config.timer_mode= TMR_MODE_COMPARE;
	Timer_init(&timer_config);


	home_display();

	uint8 key=0,temp,distance,window1_state,window2_state,code1,code2,n_faults=0;
	uint8 faults[60];   // store all received characters

	while(1)
	{
		key = KEYPAD_getPressedKey();

		switch(key)
		{
		case 1:
			UART_sendByte(START_CAR);
			g_car_state=1;
			LCD_clearScreen();
			LCD_moveCursor(1,0);
			LCD_displayString("Operation Started");
			LCD_moveCursor(2,0);
			LCD_displayString("Monitoring Active");

			g_sec=0;
			while(g_sec<DELAY);
			//			_delay_ms(5000);
			home_display();
			key=0;
			break;

		case 2:
			LCD_clearScreen();
			UART_sendByte(DISPLAY);
			do{
				g_sec=0;
				while(g_sec<DELAY){

					while (UART_recieveByte() != 0xAA);
					uint8 x =UART_recieveByte();
					if(x!=FALSE_START){
						// Read the 4 data bytes
						temp = x;
						distance = UART_recieveByte();
						window1_state = UART_recieveByte();
						window2_state = UART_recieveByte();


						LCD_moveCursor(0,0);
						LCD_displayString("Temp= ");
						LCD_intgerToString(temp);
						LCD_displayString(" C ");

						LCD_moveCursor(1,0);
						LCD_displayString("Distance= ");
						LCD_intgerToString(distance);
						LCD_displayString(" m ");

						LCD_moveCursor(2,0);
						LCD_displayString("Win1: ");
						if(window1_state==OPEN){
							LCD_displayString("OPEN ");
						}
						else{
							LCD_displayString("CLOSE");
						}

						LCD_moveCursor(3,0);
						LCD_displayString("Win2: ");
						if(window2_state==OPEN){
							LCD_displayString("OPEN ");
						}
						else{
							LCD_displayString("CLOSE");
						}
						UART_sendByte(CONT);
					}
					else{
						LCD_moveCursor(1,0);
						LCD_displayString("Please ");
						LCD_moveCursor(2,0);
						LCD_displayString("Start car first ");
						while(g_sec<DELAY);
						home_display();
						key=0;
						break;

					}
				}

				UART_sendByte(0);
				if(g_car_state){
					LCD_clearScreen();
					LCD_moveCursor(0,0);
					LCD_displayString("display again:");
					LCD_moveCursor(1,0);
					LCD_displayString("press 2");
					LCD_moveCursor(2,0);
					LCD_displayString("main menu:");
					LCD_moveCursor(3,0);
					LCD_displayString("any other button");
					key = KEYPAD_getPressedKey();
					if(key!=2){
						home_display();
						key=0;
						break;
					}
					else{
						LCD_clearScreen();
						UART_sendByte(DISPLAY);
					}
				}
			}while(key==2);

			break;


			//////////////////////////////                        //////////////////////////////////
		case 3:

			LCD_clearScreen();
			LCD_moveCursor(0,0);
			LCD_displayString("Logged Faults:");


			UART_sendByte(FAULTS);
			if(g_car_state){

				uint8 n_faults=0;
				while(1){

					while (UART_recieveByte() != 0xAA);
					faults[n_faults]=UART_recieveByte();
					if(faults[n_faults]==0){
						break;
					}
					n_faults++;
				}

				if(n_faults==0){
					LCD_clearScreen();
					LCD_displayString("No Faults Logged");
				}
				else{
					uint8 i=0;
					while (i < n_faults)
					{
						LCD_clearScreen();
						LCD_displayString("Logged Faults:");

						// First line
						LCD_moveCursor(1, 0);
						if (i < n_faults)
						{
							if(faults[i]==P001_CODE){
								LCD_intgerToString(i+1);
								LCD_displayString(") P001");
							}
							else if(faults[i]==P002_CODE){
								LCD_intgerToString(i+1);
								LCD_displayString(") P002");
							}
						}

						// Second line
						LCD_moveCursor(2, 0);
						if (i + 1 < n_faults)
						{
							if(faults[i]==P001_CODE){
								LCD_intgerToString(i+2);
								LCD_displayString(") P001");
							}
							else if(faults[i]==P002_CODE){
								LCD_intgerToString(i+2);
								LCD_displayString(") P002");
							}
						}

						// Wait before scrolling
						_delay_ms(1500);

						i +=2; // move to next two faults
					}

					LCD_moveCursor(3,0);
					LCD_displayString("--End of List--");
				}
			}

			else{
				LCD_clearScreen();
				LCD_moveCursor(1,0);
				LCD_displayString("Please ");
				LCD_moveCursor(2,0);
				LCD_displayString("Start car first ");
			}
			g_sec=0;
			while(g_sec<=DELAY);

			UART_sendByte(0);
			home_display();
			key=0;
			break;

			//////////////////                       //////////////////////////

		case 4:
			UART_sendByte(STOP_CAR);
			g_car_state=0;
			LCD_clearScreen();
			LCD_displayString("System Stopped!");

			g_sec=0;
			while(g_sec<DELAY);
			home_display();
			key=0;
			break;

		default:
			UART_sendByte(CONT);
			break;
		}


	}
}

void home_display(void){
	// return to menu
	LCD_clearScreen();
	LCD_moveCursor(0,0);
	LCD_displayString("1.Start");
	LCD_moveCursor(1,0);
	LCD_displayString("2.Display");
	LCD_moveCursor(2,0);
	LCD_displayString("3.Faults");
	LCD_moveCursor(3,0);
	LCD_displayString("4.Stop");
	return;
}
