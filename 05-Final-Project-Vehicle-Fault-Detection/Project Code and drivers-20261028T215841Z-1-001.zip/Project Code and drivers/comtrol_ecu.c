#include "DC_motor.h"
#include "external_eeprom.h"
#include "lm35_sensor.h"
#include "adc.h"
#include "uart.h"
#include "pwm_t0.h"
#include "avr/io.h"
#include "Ultrasonic.h"
#include "twi.h"
#include <avr/interrupt.h>
#include "buttons.h"
#include"util/delay.h"



#define START_CAR	1
#define DISPLAY		2
#define FAULTS		3
#define STOP_CAR	4
#define EXIT		5

#define CLOSE		0
#define OPEN		1

#define P001_CODE	1
#define P002_CODE	2

#define FALSE_START		200

volatile uint8 g_car_state=0,n_faults=0;

uint8 window1_state = CLOSE, window2_state = CLOSE, fault_det;


static uint8 n_fault_det=0;
static uint8 distance_fault_active = 0;
static uint8 temperature_fault_active = 0;

void fault_detect(uint8 distance,uint8 temprature);
void window_check(void);

int main(){

	SREG|=(1<<7);
	TWI_init();

	ADC_ConfigType adc_config;
	adc_config.ref_volt= INTERNAL_2_56V ;
	adc_config.prescaler= ADC_PRESCALER_64;

	UART_ConfigType uart_config;
	uart_config.baud_rate =9600;
	uart_config.bit_data=EIGHT_BIT;
	uart_config.parity=UART_PARITY_OFF;
	uart_config.stop_bit=TWO_BIT;
	UART_init(&uart_config);


	uint8 code,display_state;
	uint8 command;
	uint8 temperature=0;
	uint16 distance=100;


	EEPROM_writeByte(0x0000, 0XFF);
	_delay_ms(10);
	EEPROM_writeByte(0x0001, 0XFF);
	_delay_ms(10);

	while(1){
		// fault detection
		fault_detect(distance,temperature);
		//window control
		window_check();

		command = UART_recieveByte();

		if (command == START_CAR)
		{
			g_car_state=1;
			buttons_INIT();
			DcMotor_Init();
			Ultrasonic_init();
			ADC_init(&adc_config);
			temperature = LM35_getTemperature();
			distance =Ultrasonic_readDistance();
			window_check();
			fault_detect(distance,temperature);

		}

		else if (command == DISPLAY)
		{
			// stay in display mode;
			if(g_car_state==1){
				display_state=1;
				while (display_state)
				{

					window_check();
					// Read current sensor values
					temperature = LM35_getTemperature();
					distance = Ultrasonic_readDistance();
					fault_detect(distance,temperature);

					// Send frame of data
					UART_sendByte(0xAA);             // start frame
					UART_sendByte(temperature);
					UART_sendByte((uint8)distance);
					UART_sendByte(window1_state);
					UART_sendByte(window2_state);


					display_state=UART_recieveByte(); // EXIT command = stop display mode
				}
			}
			else{
				UART_sendByte(0xAA); // Start frame marker
				UART_sendByte(FALSE_START); // End frame marker
				UART_sendByte(0x55); // End frame marker

			}


		}

		else if (command == FAULTS)
		{
			if(g_car_state==1){

				n_fault_det=0;

				while(1){
					EEPROM_readByte(n_fault_det, &code);
					if (code == 0xFF || code == 0){
					UART_sendByte(0xAA); // Start frame marker
					UART_sendByte(0);
						break;
					}

					UART_sendByte(0xAA); // Start frame marker
					UART_sendByte(code);
					n_fault_det++;
					_delay_ms(20);
				}

				UART_sendByte(0xAA); // Start frame marker
				UART_sendByte(EXIT);
				UART_sendByte(0x55);             // end frame

			}
			else{
				UART_sendByte(0xAA); // Start frame marker
				UART_sendByte(EXIT);
				UART_sendByte(0x55);             // end frame


			}

		}
		else if (command == STOP_CAR)
		{
			g_car_state=0;
			// stop all sensors/motors
			DcMotor_DeInit();

		}
		else{
			if(g_car_state){
				temperature = LM35_getTemperature();
				distance = Ultrasonic_readDistance();
				fault_detect(distance,temperature);
				window_check();
			}
			else{

			}
		}
	}
}





void fault_detect(uint8 distance, uint8 temperature) {
	// ---- Distance Fault ----
	if (distance < 10) {
		if (!distance_fault_active) {  // first time fault detected
			distance_fault_active = 1;

			EEPROM_writeByte((0x000+n_fault_det), P001_CODE);
			_delay_ms(20);

			n_fault_det++;
		}
	}
	else {
		distance_fault_active = 0; // reset when condition clears
	}

	// ---- Temperature Fault ----
	if (temperature > 90) {
		if (!temperature_fault_active) {  // first time fault detected
			temperature_fault_active = 1;

			EEPROM_writeByte((0x0000+n_fault_det), P002_CODE);
			_delay_ms(20);

			n_fault_det++;
		}
	}
	else {
		temperature_fault_active = 0; // reset when condition clears
	}
	//	EEPROM_writeByte((0x0000), n_fault_det);
	//	_delay_ms(10);

}


void window_check(void){

	if(g_car_state){
		//		if(window1_state==CLOSE)
		//			DcMotor_Rotate(CW,100, MOTOR1);
		//		else
		//			DcMotor_Rotate(ACW,100, MOTOR1);
		//
		//		if(window2_state==CLOSE)
		//			DcMotor_Rotate(CW,100, MOTOR2);
		//		else
		//			DcMotor_Rotate(ACW,100, MOTOR2);



		switch(button_pressed()){
		case 1://window1 open
			if(window1_state==CLOSE){
				DcMotor_Rotate(ACW,100, MOTOR1);
				_delay_ms(1000);
				DcMotor_Rotate(STOP,100, MOTOR1);
				window1_state=OPEN;
			}
			else{
			}
			break;
		case 2://window1 close
			if(window1_state==OPEN){
				DcMotor_Rotate(CW,100, MOTOR1);
				_delay_ms(1000);
				DcMotor_Rotate(STOP,100, MOTOR1);
				window1_state=CLOSE;
			}
			else{
			}
			break;
		case 3://window2 open
			if(window2_state==CLOSE){
				DcMotor_Rotate(ACW,100, MOTOR2);
				_delay_ms(1000);
				DcMotor_Rotate(STOP,100, MOTOR2);
				window2_state=OPEN;
			}
			else{
			}
			break;
		case 4://window2 close
			if(window2_state==OPEN){
				DcMotor_Rotate(CW,100, MOTOR2);
				_delay_ms(1000);
				DcMotor_Rotate(STOP,100, MOTOR2);
				window2_state=CLOSE;
			}
			else{
			}
			break;
		}

	}
	else{
		DcMotor_Rotate(STOP,0, MOTOR1);
		DcMotor_Rotate(STOP,0, MOTOR2);
	}

}
